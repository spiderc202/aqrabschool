# aqrabschool
Donation Web Application or AqrabSchool

This web application form is designed to do as below:
- Create a page where people can donate per lot to any school or charity
- Integrates with BillPlz payment gateway
